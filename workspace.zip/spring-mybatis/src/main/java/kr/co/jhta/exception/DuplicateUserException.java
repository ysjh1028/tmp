package kr.co.jhta.exception;

public class DuplicateUserException extends HTAException {

	public DuplicateUserException(String message) {
		super(message);
	}
}
