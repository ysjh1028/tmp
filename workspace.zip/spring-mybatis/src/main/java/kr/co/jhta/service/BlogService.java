package kr.co.jhta.service;

public interface BlogService {

}
