package kr.co.jhta.exception;

public class UnauthenticateUserException extends HTAException {

	public UnauthenticateUserException(String message) {
		super(message);
	}
}
